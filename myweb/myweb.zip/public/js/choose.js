var up=document.querySelector("#upload");				
up.onclick=function(){
	window.open("/up",'_parent');
};						

var down=document.querySelector("#download");			
down.onclick=function(){
	window.open("/down",'_parent');
};

						
